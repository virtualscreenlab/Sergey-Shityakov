echo "length coverage sequences contigs"
for l in 100 400 800; do
   for i in 1 2 3 4 5 6 7 8 9 ;do
   ./sequencer -c $i -l $l -r --circular-genome *.seq > output
      run_TA output
      SEQ1=$(grep -c ">" output)
      SEQ2=$(grep -c ">" output.fasta)
      echo $l $i $SEQ1 $SEQ2
 done
done



